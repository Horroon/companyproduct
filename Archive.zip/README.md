## Project info
<p>start your project by following simple steps.</p>
<ul>
  <li>npm install</li>
  <li>npm start</li>
</ul>
<p>open project in your browser by http://localhost:3000/</p>
<p>if port not works than see the terminal on what port project running</p>
