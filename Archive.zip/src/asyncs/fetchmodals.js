import CarModals from "../db/modals.json";

export const FetchModal = () => CarModals; // you can define exact async function here
