import Header from "./header";
import Footer from "./footer";
import { Search } from "./search";
export { Header, Footer, Search };
