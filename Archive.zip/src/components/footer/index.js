import React from "react";

export default function Footer(params) {
  return <footer>Footer Test</footer>;
}
