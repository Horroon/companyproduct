import Mainscreen from "./screens";
import "antd/dist/antd.css";

export default Mainscreen;
