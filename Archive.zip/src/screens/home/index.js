import React from "react";
import { Content } from "../content";

export const Homescreen = () => {
  return (
    <div className="container">
      <div className="row my-10">
        <Content />
      </div>
    </div>
  );
};
