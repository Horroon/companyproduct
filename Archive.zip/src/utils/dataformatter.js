export function DataFormatter(data){
    //return data.map(cmodal=>({modal: }))
}